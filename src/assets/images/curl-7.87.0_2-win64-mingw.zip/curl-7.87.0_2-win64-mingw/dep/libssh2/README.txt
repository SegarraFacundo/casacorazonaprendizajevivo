libssh2 - SSH2 library
======================

libssh2 is a library implementing the SSH2 protocol, available under
the revised BSD license.

Web site: https://www.libssh2.org/

Mailing list: https://cool.haxx.se/mailman/listinfo/libssh2-devel

License: see COPYING

Source code: https://github.com/libssh2/libssh2

Web site source code: https://github.com/libssh2/www

Installation instructions are in:
 - docs/INSTALL_CMAKE for CMake
 - docs/INSTALL_AUTOTOOLS for Autotools
